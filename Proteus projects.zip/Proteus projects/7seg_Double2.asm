PRINTC MACRO VAR1
    MOV DL,VAR1
    MOV AH,2
    INT 21H
ENDM 

PRINTS MACRO VAR1
    MOV DX,VAR1
    MOV AH,9
    INT 21H
ENDM 

ESPACE MACRO X1
    MOV DL,X1
    MOV AH,2
    INT 21H 

ENDM

SCANC MACRO X1
      MOV AH,1
      INT 21H     
ENDM 


DATA SEGMENT
    UNITE DB 30H,31H,32H,33H,34H,35H,36H,37H,38H,39H
    MSG DB "SAISIR LE COMMANDE 0. COMPTEUR 1. DECOMPTEUR : $"
DATA ENDS

STACK SEGMENT
    DW 127 DUP<0>
STACK ENDS

CODE SEGMENT    
START:  
    MOV AX,DATA
    MOV DS,AX
    MOV ES,AX 
    
    LEA BX,MSG
    PRINTS BX
    SCANC      
    LEA BX,UNITE
    PUSH BX
     
    CMP AL,30H
    JE DEBUT      
    CALL DECOMPTEUR 
    JMP TERMINER
    DEBUT:
    CALL COMPTEUR
   
    TERMINER:
    MOV SP,2    
    
    MOV AH,4CH
    INT 21H
    
 
COMPTEUR PROC NEAR
    PUSH BP
    MOV BP,SP
    
    MOV BX,4[BP]
    XOR SI,SI
    XOR DI,DI
    MOV CX,00AH
    ;COMPTER 
    UP:
    CMP DI,CX
    JGE FIN1

       ICI:
       CMP SI,CX
       JGE TANTQUE
         PRINTC [BX][SI]
         ESPACE 20H
         PRINTC [BX+DI]
         CALL TEMPO
         INC SI
         CMP SI,09H
         JNE NEXT
            INC DI 
         NEXT:
      JMP ICI
      TANTQUE: 
   XOR SI,SI
   JMP UP
   FIN1:

   
    POP BP
    RET
COMPTEUR ENDP        


DECOMPTEUR PROC NEAR
    PUSH BP
    MOV BP,SP
    
    MOV BX,4[BP]
    MOV SI,00AH
    MOV DI,00AH
    
    ;COMPTER 
    DOWN:
    CMP DI,00H
    JE FIN2
    
       ICI1:
       CMP SI,00H
       JLE TANTQUE1
         PRINTC [BX+SI-1]
         ESPACE 20H
         PRINTC [BX+DI-1]
         CALL TEMPO
         DEC SI
         CMP SI,01H
         JNE NEXT1
            DEC DI 
         NEXT1:
      JMP ICI1
      TANTQUE1: 
   MOV SI,0AH
   JMP DOWN
   FIN2:

   
    POP BP
    RET
DECOMPTEUR ENDP        


TEMPO PROC NEAR
    PUSH CX
    MOV CX,0FH
    COMPTEUR1:
    LOOP COMPTEUR1
    POP CX
    RET 
TEMPO ENDP

FIN: 

CODE ENDS    